package com.regzan.skyraid.events.arenasetup;

class config {
}
