package com.regzan.skyraid.events.arenasetup;

public class padLoc {


}
